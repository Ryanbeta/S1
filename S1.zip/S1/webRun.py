import tornado.ioloop
import tornado.web
import tornado.httpclient
import tornado.httpserver
import json
import os
import myTool.sshConnect
from tornado.concurrent import Future


def async_fetch_future(url):
    http_client = tornado.httpclient.AsyncHTTPClient()
    my_future = Future()
    fetch_future = http_client.fetch(url)
    fetch_future.add_done_callback(
        lambda f: my_future.set_result(f.result()))
    return my_future


class MyFormHandler(tornado.web.RequestHandler):
    def prepare(self):
        try:
            print self.request
            if self.request.headers["Content-Type"].startswith("application/json"):
                self.json_args = json.loads(self.request.body)
            else:
                self.json_args = None
        except:
            pass

    def get(self):
        print "MyFormHandler get"
        #self.set_header("Content-Type", "text/plain")
        self.write('<html>'
                   '<head><title>Send Message</title></head>'
                   '<body>'
                   '<form action="/test" method="post">'
                   '<label FOR="message1">Message to Send</Label><br>'
                   '<textarea ID=message1 name=message1 wrap=hard placeholder="opercmd:{}"></textarea><br>'
                   '<input type="submit" value="SUBMIT">'
                   '</form>'
                   '</body></html>'
                   )


    def post(self):
        print "MyFormHandler post"
        self.write('<html><title>Result</title>'
                   '<body>'
                   '<form action = "/test" method = "get">'
                   'You send %s<br>'
                   '<input type="submit" value="Return">'
                   '</form>'
                   '</html>'%self.get_argument("message1"))
        #async_fetch_future("http://localhost:8888/test")


class MainHandler(tornado.web.RequestHandler):
    def get(self):
        print "MainHandler get"
        os.path.join(os.path.dirname(__file__), "templates")
        self.render('login.html')

    def post(self):
        print "MainHandler post"
        self.set_header("Content-Type", "text/plain")
        self.write("You tried to access " + self.get_argument("hostname"))
        #self.redirect("/test")


class StoryHandler(tornado.web.RequestHandler):
    def get(self, story_id):
        self.write("You requested the story " + story_id)

class IndexHandler(tornado.web.RequestHandler):
    def get(self):
        items = ["Item 1", "Item 2", "Item 3"]
        self.render('index.html', title="My title", items=items)


def make_app():
    return tornado.web.Application([
        (r"/", MainHandler),
        (r"/story/([0-9]+)", StoryHandler),
        (r"/test", MyFormHandler),
        (r"/index", IndexHandler)
    ])

def main():
    app = make_app()
    server = tornado.httpserver.HTTPServer(app)
    server.bind(8888)
    server.start(0)  # forks one process per cpu
    tornado.ioloop.IOLoop.current().start()


if __name__ == "__main__":
    main()
