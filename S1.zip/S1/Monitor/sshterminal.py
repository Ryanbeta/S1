import paramiko
import time
import pandas as pd
import threading
import os
import re
from pandas import DataFrame
from myTool.logger import logger


class netdevice(object):

    def __init__(self):
        self._manufacture = None
        self._name = None
        self._type = None
        self._sn = None
        self._ip = None
        self._username = None
        self._password = None
        self._priority = None
        self.remote_conn_pre = paramiko.SSHClient()

    @property
    def name(self):
        return self._name

    @classmethod
    def pushCommands(self, ip, port=22, username='', password='', cmds=[], interval = [], exportdir = '',enforce = "1",errcode = ['Error', 'Invalid input']):
        output = ''
        try:
            self.remote_conn_pre.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self.remote_conn_pre.connect(ip, port=port, username=username,
                                    password=password,
                                    look_for_keys=False, allow_agent=False)

            remote_conn = self.remote_conn_pre.invoke_shell()
            output += remote_conn.recv(65535)
            ind = 0
            if type(cmds)!=list:
                cmds = list(cmds)

            while(ind<cmds.__len__()):
                val = cmds[ind]
                data = str( val + '\n')
                remote_conn.send(data)
                if interval == [] | interval[ind]==0:
                    sleeptime = 0.2
                else:
                    sleeptime = interval[ind]
                time.sleep(sleeptime)
                output = str(remote_conn.recv(65535))
                if output.find('More')>=0:
                    if ind+1 == cmds.__len__():
                        cmds.append(' ')
                    else:
                        cmds.insert(ind+1,' ')
                ind += 1
                output = self._prettyoutput(output,[' --More-- ','        '], '')
                output += output
                if self._haserr(output,errcode) | enforce != '1':
                    logger.error('Error found, stop@%s',val)

                    break
            logger.info(cmds)
            remote_conn.close()
            self.remote_conn_pre.close()
        finally:
            logger.info('pushCommands finish')
            if not exportdir.__eq__(''):

            return output

    @classmethod
    def _prettyoutput(self, message = str, oldReplace = list,newRlace=str):
        result = ''
        for i in oldReplace:
            result = result.replace(i,newRlace)
        return result

    @classmethod
    def _haserr(self, raw = str, err = list):
        for i in err:
            if raw.__contains__(i):
                return True
        return False

    @classmethod
    def _getdevicename(self, raw = str):
        result = ''
        tmp1 = re.search(r'<(?P<name>[A-Z].*)>', raw)
        if (tmp1):
            result = tmp1.group('name')
        tmp1 = re.search(r'(?P<name>[A-Z].*)\#', raw)
        if (tmp1):
            result = tmp1.group('name')
        return result

if __name__=='__main__':
    rootDir = '../res/'
    _export_dir = 'backup'
    config = pd.read_csv(filepath_or_buffer='../res/desc1.csv', encoding='utf-8',na_filter=False,)
    export_path = rootDir + os.path.sep + _export_dir
    if not os.path.isdir(export_path):
        os.mkdir(export_path)

    print config
    for ind in range(config["Index"].count()):
        Result = ''
        netdevice
        if config['Username'][ind].__eq__('') | config['Password'][ind].__eq__('') :
            continue
        a = threading.Thread(target=netdevice.pushCommands,args = (ip,))
        a.start()