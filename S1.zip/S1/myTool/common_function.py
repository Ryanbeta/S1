# coding: UTF-8

import pandas as pd
from pandas import Series, DataFrame
import numpy as np
import IPy
from IPy import IP, IPSet
import re, copy
import os, io
from logger import logger
import xlrd
import xlwt

_export_dir = 'export'
_cisco = 'Cisco'
_huawei = 'Huawei'
pd.set_option('display.max_colwidth', 250)


def IsSubString(SubStrList, Str):
    flag = True
    flag_or = True
    for substr in SubStrList:
        if isinstance(substr, list):
            flag_or = False
            for sub_i in substr:
                if sub_i in Str:
                    flag_or = True
        elif not (substr in Str):
            flag = False
    return flag & flag_or


def GetFileName(level, path, FlagStr):
    filelist = []
    files = os.listdir(path)
    for f in files:
        if os.path.isfile(path + os.path.sep + f):
            if isinstance(FlagStr, str) and f.find(FlagStr) >= 0:
                filelist.append(f)
                continue
            if isinstance(FlagStr, list):
                if IsSubString(FlagStr, f):
                    filelist.append(f)
    return filelist


# 根据设备名在目录读一个文件，文件读取和预处理
def get_device_config(rootDir, filename):
    logger.info('Processing ' + filename)
    file_object = open(rootDir + os.path.sep + filename, 'rb')
    try:
        all_the_text = file_object.read().decode('utf-8')
        all_the_text = all_the_text.replace("  ---- More ----[16D                [16D", '')
        all_the_text = all_the_text.replace("  ---- More ----                ", '')
    finally:
        file_object.close()
    return all_the_text


# 配置文件分类器，判断厂家，设备名，配置所有使用的命令列表
def command_classify(text):
    dict_classify = {'device': '', 'manuf': '', 'command': '', 'last change': '', 'last save': ''}
    tmp1 = re.search(r'<(?P<name>[A-Z].*)>', text)
    if tmp1:
        dict_classify['device'] = tmp1.group('name')
        dict_classify['manuf'] = _huawei
        dict_classify['command'] = re.findall(r'>\s*(?P<cmd>[^\r\n\d]+\w)[\s\r\n]', text)
        dict_classify['last change'] = re.findall('Last\sconfiguration\swas\supdated\sat\s([^\r\n]+)', text)
        dict_classify['last save'] = re.findall('Last\sconfiguration\swas\ssaved\sat\s([^\r\n]+)', text)
    else:
        tmp1 = re.search(r'(?P<name>[A-Z].*)\#', text)
        if (tmp1):
            dict_classify['device'] = tmp1.group('name')
            dict_classify['manuf'] = _cisco
            dict_classify['command'] = re.findall(r'\#\s*(?P<cmd>[^\r\n\d]+\w)[\s\r\n]', text)
            dict_classify['last change'] = re.findall('Last\sconfiguration\schange\sat\s([^\r\n]+)', text)
            dict_classify['last save'] = re.findall('NVRAM\sconfig\slast\supdated\sat\s([^\r\n]+)', text)
    # logger.info(dict_classify)
    return dict_classify


# 取出一份配置中，在一段命令下的有效配置
def config_per_command(config, command, separate):
    if separate == '':
        return config
    valid_config = ''
    s = 0
    e = 0
    if command == '':
        logger.info('no command')
        return config
    s = config.find(command) + len(command)
    e = config.find(separate, s)
    if s >= 0:
        if e >= 0:
            valid_config = config[s:e]
        else:
            valid_config = config[s:]
    return valid_config


# 一台设备的配置读出成DataFrame数据结构
def config_to_df(all_text, dict_classify):
    try:
        device_name = dict_classify['device']
        manufacturer = dict_classify['manuf']
        command_list = dict_classify['command']
    except ValueError:
        logger.error('error classify!')
        return

    device_frame = DataFrame()
    vlan_frame = DataFrame()
    mod_frame = DataFrame()
    flag = np.zeros(4, dtype=int)

    # 找出每条命令的分隔符
    for command in command_list:
        sep_command = ''
        sep_section = ''
        criteria = False
        if manufacturer == _cisco:
            sep_command = device_name + '#'
            if device_name.find('CW') >= 0:
                sep_section = '\r\n\r'
            else:
                sep_section = '!'
        elif manufacturer == _huawei:
            sep_command = '<' + device_name + '>'
            sep_section = '#'
        if sep_command == '':
            return all_text
        if command == '':
            continue

        config_section = config_per_command(all_text, command, sep_command)
        if command.find('sh') >= 0 and command.find(' ru') >= 0:
            if config_section.find('version') < 0:
                continue
            device_frame, vlan_frame = read_cisco_shrun(device_name, config_section, sep_section)
            continue

        if command.find('di') >= 0 and command.find(' cur') >= 0:
            if config_section.find('Software Version') < 0:
                continue
            device_frame, vlan_frame = read_huawei_discur(device_name, config_section, sep_section)
            continue

        if command.find('sh') >= 0 and command.find('inv') >= 0 and flag[0] == 0:
            if mod_frame.empty:
                mod_frame = read_cisco_shinven(device_name, config_section, sep_section)
                if not mod_frame.empty:
                    flag[0] = 1
            else:
                sub_frame = read_cisco_shinven(device_name, config_section, sep_section)
                if not sub_frame.empty:
                    flag[0] = 1
                    mod_frame = pd.concat([sub_frame, mod_frame], ignore_index=True)

        if command.find('sh') >= 0 and command.find('mod') >= 0 and flag[1] == 0:
            if config_section.find('---') < 0:
                continue
            sep_section = '\r\n\r\n'
            if mod_frame.empty:
                mod_frame = read_cisco_shmod(device_name, config_section, sep_section, manufacturer)
                if not mod_frame.empty:
                    flag[1] = 1
            else:
                sub_frame = read_cisco_shmod(device_name, config_section, sep_section, manufacturer)
                if not sub_frame.empty:
                    flag[1] = 1
                    mod_frame = pd.concat([mod_frame, sub_frame], ignore_index=True)
            continue

        criteria = re.search(r'di\w*\s+dev\w*\s*', command)
        if criteria and flag[2] == 0:
            if mod_frame.empty:
                mod_frame = frame_disdev(device_name, config_section, manufacturer)
                if not mod_frame.empty:
                    flag[2] = 1
            else:
                sub_frame = frame_disdev(device_name, config_section, manufacturer)
                if not sub_frame.empty:
                    flag[2] = 1
                    mod_frame = pd.merge(mod_frame, sub_frame, how='outer', on=['Device', 'Mod', 'Manufacturer'])
            continue

        criteria = re.search(r'dis\w*\s+dev\w*\s+manu\w*-{0,1}[^\r\n]*', command)
        if criteria and flag[3] == 0:
            if mod_frame.empty:
                mod_frame = frame_disdev(device_name, config_section, manufacturer)
                if not mod_frame.empty:
                    flag[3] = 1
            else:
                sub_frame = frame_disdev(device_name, config_section, manufacturer)
                if not sub_frame.empty:
                    flag[3] = 1
                    mod_frame = pd.merge(mod_frame, sub_frame, how='outer', on=['Device', 'Mod', 'Manufacturer'])
            continue

    return [device_frame, vlan_frame, mod_frame]


# 根目录下所有配置读出成Dataframe，封装config_to_df
def files2df(rootDir, flag):
    frame_all = [DataFrame(), DataFrame(), DataFrame()]
    file_list = GetFileName(1, rootDir, flag)
    for i in file_list:
        if IsSubString(flag, i):
            all_the_text = get_device_config(rootDir, i)
            dict_classify = command_classify(all_the_text)
            df = config_to_df(all_the_text, dict_classify)
            for index in range(len(df)):
                if df[index].empty:
                    continue
                frame_all[index] = pd.concat([frame_all[index], df[index]], ignore_index=True)
    logger.info('共处理' + str(len(file_list)) + '个文件')
    return frame_all


# 思科sh ru命令处理函数
def read_cisco_shrun(device_name, all_the_text, conf_split):
    device_row_list = []
    vlan_row_list = []
    vlan_name_list = []
    device_index = []
    vlan_frame = DataFrame()
    device_manufacturer = "Cisco"

    text_split = all_the_text.split(conf_split)
    if device_manufacturer == "Cisco":
        for i in text_split:
            valid_partition = re.search(r'\d_(?P<part>[^_]+)_', device_name)
            device_dict = {'Device': device_name, 'Manufacturer': device_manufacturer, 'Partition': '',
                           'Port Prefix': '', 'Mod': '', 'Port': '', 'Description': '', 'Status': '', 'IP': '',
                           'Standby IP': '', 'AT': '', 'Vlan': ''}
            vlan_dict = {'Device': device_name, 'No': np.nan, 'Description': '', 'Status': '', 'IP': '', 'CIDR': '',
                         'IPstart': '',
                         'Secondary IP': '', 'Standby IP': ''}
            vlan_name_dict = {'Device': device_name, 'No': np.nan, 'Name': ''}
            valid_config = re.search(r'[\r\n]interface\s(?P<Port>[^V\s]+[^\r\n])', i)
            valid_device_vlan = re.search(r'\sswitchport.*vlan\s(?P<vlan>[^\r\n]+)', i)
            valid_device_vlan_add = re.findall(r'\sswitchport.*vlan\sadd\s(?P<vlan>[^\r\n]+)', i)
            valid_vlan = re.match(r'[\r\n]\svlan\s(?P<Vlan>\d+)[\r\n]', i)
            if valid_partition:
                device_dict['Partition'] = valid_partition.group('part')
            if valid_config:
                port_tmp = re.search(r'(?P<type>[^\d\s\r\n]+)(?P<card>\d+)/(?P<port>\d+)', valid_config.group('Port'))
                if port_tmp:
                    device_dict['Port Prefix'] = port_tmp.group('type')
                    device_dict['Mod'] = port_tmp.group('card')
                    device_dict['Port'] = port_tmp.group('port')
                else:
                    device_dict['Port Prefix'] = valid_config.group('Port')
                valid_desc = re.search(r'\sdescription\s(?P<Desc>[^\r\n]+)', i)
                if valid_desc:
                    device_dict['Description'] = valid_desc.group('Desc')
                valid_ip = re.search(r'ip\saddress(?P<IP>[^\r\n]+)', i)
                if valid_ip and valid_ip.group('IP').__len__() > 2:
                    device_dict['IP'] = valid_ip.group('IP')
                valid_ip = re.search(r'\sstandby\s\d+\sip\s(?P<IP>[^\r\n]+)', i)
                if valid_ip and valid_ip.group('IP').__len__() > 2:
                    device_dict['Standby IP'] = valid_ip.group('IP')
                if valid_device_vlan:
                    device_dict['Vlan'] = str(valid_device_vlan.group('vlan'))
                if valid_device_vlan_add:
                    for vlan_add in valid_device_vlan_add:
                        device_dict['Vlan'] = device_dict['Vlan'] + ', ' + str(vlan_add)
                if re.search(r'\W\sshutdown', i):
                    device_dict['Status'] = "shutdown"
                if i.find('switchport access') > 0:
                    device_dict['AT'] = 'access'
                if i.find('switchport mode trunk') > 0:
                    device_dict['AT'] = device_dict['AT'] + 'trunk'
                if device_dict not in device_row_list:
                    device_row_list.append(device_dict)
                    if device_dict['Mod'] == '':
                        device_index.append(device_name + ' ' + device_dict['Port Prefix'])
                    else:
                        device_index.append(device_name + ' ' + device_dict['Mod'] + '/' + device_dict['Port'])

            valid_config_vlan = re.search(r'[\r\n]interface\sVlan(?P<Vlan>\S+)[\r\n]', i)
            if valid_config_vlan:
                vlan_dict['No'] = int(valid_config_vlan.group('Vlan'))
                valid_desc = re.search(r'\sdescription\s(?P<Desc>[^\r\n]+)', i)
                if valid_desc:
                    vlan_dict['Description'] = valid_desc.group('Desc')
                valid_ip = re.search(r'ip\saddress\s(?P<IP>[\d\.\s]+)[\s]*\r\n', i)
                if valid_ip and valid_ip.group('IP').__len__() > 2:
                    ip_in_conf = valid_ip.group('IP')
                    vlan_dict['IP'] = ip_in_conf

                    ip_in_conf_f = ip_in_conf.find(' ')
                    if (ip_in_conf_f > 0):
                        vlan_dict['CIDR'] = IP(ip_in_conf[:ip_in_conf_f]).make_net(
                            ip_in_conf[ip_in_conf_f + 1:]).strNormal(1)
                        vlan_dict['IPstart'] = IP(ip_in_conf[:ip_in_conf_f]).make_net(
                            ip_in_conf[ip_in_conf_f + 1:]).net().int()
                    else:
                        vlan_dict['IPstart'] = IP(ip_in_conf).int()
                valid_standby_ip = re.findall(r'\sstandby\s(\d+)\sip\s(?P<IP>[^\r\n]+)', i)
                if len(valid_standby_ip) == 1:
                    vlan_dict['Standby IP'] = str(valid_standby_ip)[2:-2]
                else:
                    for standby_i in valid_standby_ip:
                        vlan_dict['Standby IP'] = vlan_dict['Standby IP'] + '|' + str(standby_i)
                valid_secondary_ip = re.findall(r'\sip\saddress\s(?P<IP>[^\r\n]+)\ssecondary', i)
                if len(valid_secondary_ip) == 1:
                    vlan_dict['Secondary IP'] = str(valid_secondary_ip)[2:-2]
                else:
                    for second_i in valid_secondary_ip:
                        vlan_dict['Secondary IP'] = vlan_dict['Secondary IP'] + '|' + str(second_i)
                if re.search(r'\W\sshutdown', i):
                    vlan_dict['Status'] = "shutdown"
                if vlan_dict not in vlan_row_list:
                    vlan_row_list.append(vlan_dict)

            if valid_vlan:
                vlan_name_dict['Device'] = device_name
                tmp = re.findall(r'\d+\.{3}\d+', i)
                if tmp != []:
                    print(tmp)
                vlan_name_dict['No'] = int(valid_vlan.group('Vlan'))
                valid_vlan_name = re.search(r'name\s(?P<vlan_name>[^\r\n]+)', i)
                if valid_vlan_name:
                    vlan_name_dict['Name'] = valid_vlan_name.group('vlan_name')
                if vlan_name_dict not in vlan_name_list:
                    vlan_name_list.append(vlan_name_dict)

    device_frame = pd.DataFrame(device_row_list,
                                columns=['Device', 'Manufacturer', 'Partition', 'Port Prefix', 'Mod', 'Port',
                                         'Description', 'Status', 'IP', 'Standby IP', 'AT', 'Vlan'], index=device_index)
    if len(vlan_row_list):
        vlan_frame = pd.DataFrame(vlan_row_list,
                                  columns=['Device', 'No', 'Description', 'Status', 'IP', 'Secondary IP', 'Standby IP',
                                           'CIDR', 'IPstart'])
    if len(vlan_name_list):
        vlan_name_frame = pd.DataFrame(vlan_name_list, columns=['No', 'Name', 'Device'])
        vlan_frame = pd.merge(vlan_frame, vlan_name_frame, how='outer', on=['No', 'Device'])
    return device_frame, vlan_frame


def getcolumn(a, mains, sep):
    r = []
    l_t = 0
    tmp = re.findall(r'' + mains + '+' + sep + '+', a)
    for i in tmp:
        r.append(len(i))
        l_t += len(i)
    if l_t < len(a):
        r.append(len(a) - l_t)
    return r


# 处理sh mod 中的一个表格
def frame_shmod(device_name, text_split):
    result = DataFrame()
    s = text_split.find('--')
    e = text_split.find('\r\n', s)
    sep_type = '\s'
    if (s >= 0 and e >= 0):
        #   旧版本IOS中存在分栏符为+的情况
        if (text_split[s:e].find('+') >= 0):
            sep_type = '\+'
        # 获取sh mod中每一栏的宽度
        width = getcolumn(text_split[s:e], '-', sep_type)
        # regulate
        tmps = text_split[:s - 1] + text_split[e + 1:]
        # OA设备中旧版本IOS 显示问题，MAC一栏只有M开头的一行
        s = tmps.find('Mod')
        if s >= 0:
            tmps = tmps[s:]
            sub_frame = pd.read_fwf(io.StringIO(tmps), widths=width)
            sub_frame.insert(loc=0, column='Device', value=device_name)
            result = sub_frame
        s = tmps.find(' M ')
        if s >= 0:
            tmps = tmps[s:]
            sub_frame = pd.read_fwf(io.StringIO(tmps), widths=width)
            sub_frame.insert(loc=0, column='Mod', value=sub_frame['M'].values)
            sub_frame.pop('M')
            sub_frame.insert(loc=0, column='Device', value=device_name)
            result = sub_frame
        s = tmps.find('Module-Type')
        if s >= 0 and not result.empty:
            result.insert(loc=0, column='Card Type', value=result['Module-Type'].values)
            result.pop('Module-Type')
        s = tmps.find('MAC-Address(es)')
        if s >= 0 and not result.empty:
            result.insert(loc=0, column='MAC addresses', value=result['MAC-Address(es)'].values)
            result.pop('MAC-Address(es)')
        s = tmps.find('Serial-Num')
        if s >= 0 and not result.empty:
            result.insert(loc=0, column='Serial No.', value=result['Serial-Num'].values)
            result.pop('Serial-Num')
    return result


# 思科sh mod命令处理函数
def read_cisco_shmod(device_name, config, conf_split, manufacturer):
    frame_type = DataFrame()
    frame_mac = DataFrame()
    frame_status = DataFrame()
    frame_mod = DataFrame()
    device_frame = DataFrame()
    vlan_frame = DataFrame()
    for text_split in config.split(conf_split):
        # 输出不规范，可能在分栏存在空格
        if text_split.find('\r\n       ') >= 0:
            text_split = text_split[:text_split.find('\r\n       ')]
        if (text_split.find('Card Type') >= 0 or text_split.find('Module-Type') >= 0) and text_split.find('Xbar') < 0:
            # read Mod, ports, card type, model, serial No
            frame_type = frame_shmod(device_name, text_split)
            continue
        if (text_split.find('MAC addresses') >= 0 or text_split.find('MAC-Address(es)') >= 0) and text_split.find(
                'Xbar') < 0:
            # read Mod, Hw, Fw, Sw, Status
            frame_mac = frame_shmod(device_name, text_split)
            continue
        if (text_split.find('Online Diag Status') >= 0) and text_split.find('Xbar') < 0:
            # read Mod, Online Diag Status
            frame_status = frame_shmod(device_name, text_split)
            continue
    if not frame_type.empty and not frame_mac.empty:
        frame_mod = pd.merge(frame_type, frame_mac, how='outer', on=['Device', 'Mod'])
    if not frame_type.empty and not frame_status.empty:
        frame_mod = pd.merge(frame_mod, frame_status, how='outer', on=['Device', 'Mod'])
    if not frame_mod.empty:
        frame_mod.insert(loc=0, column='Manufacturer', value=manufacturer)
    return frame_mod


def read_cisco_shinven(device_name, config, conf_split):
    try:
        flag1 = 'PID: '
        t1 = config.find(flag1)
        t2 = config.find(' ', t1 + len(flag1))
        tp = config[t1 + len(flag1):t2]
        flag1 = 'SN: '
        t1 = config.find(flag1)
        t2 = config.find('\r\n', t1 + len(flag1))
        sn = config[t1 + len(flag1):t2]
    finally:
        device_frame = DataFrame({'Device': [device_name], 'Serial No.': [sn], 'Model': [tp], 'Mod': [u'机箱']})
        return device_frame


# 华为di cur 命令读取处理
def read_huawei_discur(device_name, all_the_text, conf_split):
    device_row_list = []
    vlan_row_list = []
    vlan_name_list = []
    device_index = []
    device_manufacturer = _huawei
    vlan_frame = DataFrame()
    device_frame = DataFrame()

    text_split = all_the_text.split(conf_split)
    # 历史遗留无用函数
    if device_manufacturer == _huawei:
        for i in text_split:
            valid_partition = re.search(r'\d_(?P<part>[^_]+)_', device_name)
            device_dict = {'Device': device_name, 'Manufacturer': device_manufacturer, 'Partition': '',
                           'Port Prefix': '', 'Mod': '', 'Port': '', 'Description': '', 'Status': '', 'IP': '',
                           'Standby IP': '', 'AT': '', 'Vlan': ''}
            vlan_dict = {'Device': device_name, 'No': np.nan, 'Description': '', 'Status': '', 'IP': '', 'CIDR': '',
                         'IPstart': '',
                         'Secondary IP': '', 'virtual-ip': ''}
            vlan_name_dict = {'Device': device_name, 'No': np.nan, 'Name': ''}
            valid_config = re.search(r'[\r\n]interface\s(?P<Port>[^V\s]+[^\r\n])', i)
            valid_device_vlan = re.findall(
                r'[\r\n]\sport\s(?P<at>trunk\sallow-pass\svlan\s|default\svlan\s)(?P<vlan>[^\r\n]+)', i)

            if valid_partition:
                device_dict['Partition'] = valid_partition.group('part')
            if valid_config:
                port_tmp = re.search(r'(?P<type>\w+)(?P<card>\d+/\d+|\d+)/(?P<subcard>\d+)/(?P<Mod>[^/\r\n]+)',
                                     valid_config.group('Port'))
                if port_tmp:
                    device_dict['Port Prefix'] = port_tmp.group('type')
                    if '/' not in port_tmp.group('card'):
                        device_dict['Mod'] = port_tmp.group('card')
                    else:
                        # device_dict['Mod'] = '\'' + port_tmp.group('card') <- excel中在数字前打'标示文本，暂时取消
                        device_dict['Mod'] = port_tmp.group('card')
                    if int(port_tmp.group('subcard')) > 0:
                        device_dict['Mod'] = device_dict['Mod'] + '/' + port_tmp.group('subcard')
                    device_dict['Port'] = port_tmp.group('Mod')
                else:
                    device_dict['Port Prefix'] = valid_config.group('Port')
                valid_desc = re.search(r'\sdescription\s(?P<Desc>[^\r\n]+)', i)
                if valid_desc:
                    device_dict['Description'] = valid_desc.group('Desc')
                valid_ip = re.search(r'ip\saddress(?P<IP>[^secondary\r\n]+)', i)
                if valid_ip and valid_ip.group('IP').__len__() > 2:
                    device_dict['IP'] = valid_ip.group('IP')
                valid_ip = re.search(r'\sstandby\s\d+\sip\s(?P<IP>[^\r\n]+)', i)
                if valid_ip and valid_ip.group('IP').__len__() > 2:
                    device_dict['Standby IP'] = valid_ip.group('IP')
                if valid_device_vlan:
                    for vlan_sub in valid_device_vlan:
                        device_dict['Vlan'] = device_dict['Vlan'] + ', ' + str(vlan_sub[1])
                if i.find(' shutdown') >= 0:
                    device_dict['Status'] = "shutdown"
                if i.find('port default vlan') > 0:
                    device_dict['AT'] = 'access'
                if i.find('trunk allow-pass vlan') > 0:
                    device_dict['AT'] = device_dict['AT'] + 'trunk'
                if device_dict not in device_row_list:
                    device_row_list.append(device_dict)
                    if device_dict['Mod'] == '':
                        device_index.append(device_name + ' ' + device_dict['Port Prefix'])
                    else:
                        device_index_tmp = device_name + ' ' + device_dict['Mod'] + '/0/' + device_dict['Port']
                        device_index_tmp = device_index_tmp.replace('\'', '')
                        device_index.append(device_index_tmp)

            valid_config_vlan = re.search(r'[\r\n]interface\sVlanif(?P<Vlan>\d+)[\r\n]', i)
            if valid_config_vlan:
                vlan_dict['No'] = int(valid_config_vlan.group('Vlan'))
                valid_desc = re.search(r'\sdescription\s(?P<Desc>[^\r\n]+)', i)
                if valid_desc:
                    vlan_dict['Description'] = valid_desc.group('Desc')
                valid_ip = re.search(r'ip\saddress\s(?P<IP>[\d\.\s]+)[\s]*\r\n', i)
                if valid_ip and valid_ip.group('IP').__len__() > 2:
                    ip_in_conf = valid_ip.group('IP')
                    vlan_dict['IP'] = ip_in_conf
                    ip_in_conf_f = ip_in_conf.find(' ')
                    if (ip_in_conf_f > 0):
                        vlan_dict['CIDR'] = IP(ip_in_conf[:ip_in_conf_f]).make_net(
                            ip_in_conf[ip_in_conf_f + 1:]).strNormal(1)
                        vlan_dict['IPstart'] = IP(ip_in_conf[:ip_in_conf_f]).make_net(
                            ip_in_conf[ip_in_conf_f + 1:]).net().int()
                    else:
                        vlan_dict['IPstart'] = IP(ip_in_conf).int()
                valid_secondary_ip = re.findall(r'\sip\saddress\s(?P<IP>[^\r\n]+)\ssecondary', i)
                if len(valid_secondary_ip) == 1:
                    vlan_dict['Secondary IP'] = str(valid_secondary_ip)[2:-2]
                else:
                    for second_i in valid_secondary_ip:
                        vlan_dict['Secondary IP'] = vlan_dict['Secondary IP'] + ', ' + second_i
                valid_virtual_ip = re.findall(r'\svirtual-ip\s(?P<IP>[^\r\n]+)', i)
                if len(valid_virtual_ip) == 1:
                    vlan_dict['virtual-ip'] = str(valid_virtual_ip)[2:-2]
                else:
                    for virtual_i in valid_virtual_ip:
                        vlan_dict['virtual-ip'] = vlan_dict['virtual-ip'] + '|' + virtual_i
                if re.search(r'\W\sshutdown', i):
                    vlan_dict['Status'] = "shutdown"
                if vlan_dict not in vlan_row_list:
                    vlan_row_list.append(vlan_dict)

            valid_vlan = re.search(r'[\r\n]vlan\s(?P<Vlan>\d+)[\r\n]', i)
            if valid_vlan:
                vlan_name_dict['Device'] = device_name
                vlan_name_dict['No'] = int(valid_vlan.group('Vlan'))
                valid_vlan_name = re.search(r'\sdescription\s(?P<vlan_name>[^\r\n]+)', i)
                if valid_vlan_name:
                    vlan_name_dict['Name'] = valid_vlan_name.group('vlan_name')
                # if re.search(r'\W\sshutdown', i):
                #                    vlan_name_list['Status'] = "shutdown"
                if vlan_name_dict not in vlan_name_list:
                    vlan_name_list.append(vlan_name_dict)

    device_frame = pd.DataFrame(device_row_list,
                                columns=['Device', 'Manufacturer', 'Partition', 'Port Prefix', 'Mod', 'Port',
                                         'Description', 'Status', 'IP', 'Standby IP', 'AT', 'Vlan'], index=device_index)
    if vlan_row_list != []:
        vlan_frame = pd.DataFrame(vlan_row_list,
                                  columns=['Device', 'No', 'Description', 'Status', 'IP', 'Secondary IP', 'virtual-ip',
                                           'CIDR', 'IPstart'])
    if len(vlan_name_list) > 0:
        vlan_name_frame = pd.DataFrame(vlan_name_list)
        if vlan_frame.empty:
            vlan_frame = vlan_name_frame
        else:
            vlan_frame = pd.merge(vlan_frame, vlan_name_frame, how='outer', on=['No', 'Device'])
    return device_frame, vlan_frame


# 对一条命令下的配置做读取
def read_huawei_disdevice(device_name, config, conf_split):
    frame_device = DataFrame()
    frame_manuf = DataFrame()


def frame_disdev(device_name, text, manufacturer):
    result = DataFrame()
    text_split = re.findall(r'\r\n-+\r\n[a-zA-Z\s\-]+-+\r\n', text)
    if len(text_split) > 1:
        tmp = re.findall(r'Chassis\sID:\s(\d+)', text)
    for index, text_i in enumerate(text_split):
        Chasis = tmp[index]
        p1 = text_i.find('---\r\n')
        p1 = p1 + len('---\r\n')
        p2 = text_i.find('\r\n---', p1)
        tmp_t = text_i[p1:p2]
        width = getcolumn(tmp_t, '\S', '\s')

        p1 = 0
        if len(text_split) > 1:
            p1 = text.find('Chassis ID: ' + Chasis)
        p1 = text.find('---\r\n', p1)
        p1 = p1 + len('---\r\n')
        p1 = text.find('---\r\n', p1)
        p1 = p1 + len('---\r\n')
        p2 = text.find('\r\n---', p1)
        tmp_t = tmp_t + '\r\n' + text[p1:p2]

        sub_frame = pd.read_fwf(io.StringIO(tmp_t), widths=width)
        sub_frame.insert(loc=0, column='Device', value=device_name)
        sub_frame.insert(loc=0, column='Manufacturer', value=manufacturer)
        if Chasis != '':
            for i in range(len(sub_frame['Slot'].values)):
                sub_frame['Slot'].values[i] = Chasis + '/' + sub_frame['Slot'].values[i]
        if result.empty:
            result = sub_frame
        else:
            result = pd.concat([result, sub_frame], ignore_index=True)
    # 格式规整
    try:
        result.insert(loc=0, column='Mod', value=result['Slot'].values)
        result.pop('Slot')
    except KeyError:
        1
    try:
        result.insert(loc=0, column='Model', value=result['Type'].values)
        result.pop('Type')
    except KeyError:
        1
    try:
        result.insert(loc=0, column='Serial No.', value=result['Serial-number'].values)
        result.pop('Serial-number')
    except KeyError:
        1
    return result


# 不完整的端口统计函数
def device_stat(device_frame):
    slot_per_card_used = 0
    last_card = -1
    total_cards = 0
    last_device = ''
    slot_per_card = 0
    total_slot_per_device = 0
    port_usage = []
    port_list = []

    for index, device_i in enumerate(device_frame.values):
        if device_i[4] == '':
            continue
        if last_device == '':
            last_device = device_i[0]
            last_card = device_i[4]
            total_cards = 1
            slot_per_card = 0
            slot_per_card_used = 0
            total_slot_per_device = 0
        if last_device == device_i[0]:
            if last_card == device_i[4]:
                slot_per_card += 1
                if (device_i[7] != 'shutdown'):
                    slot_per_card_used += 1
                if index == len(device_frame.values) - 1:
                    total_slot_per_device += slot_per_card
                    # 统计出口1
                    port_usage.append(
                        '板卡' + str(last_card) + ', 端口' + str(slot_per_card) + ', 已用' + str(slot_per_card_used))
                    # 统计出口1
                    port_list.append({'Device': last_device, 'Cards': total_cards, 'Slots': total_slot_per_device,
                                      'Usage': port_usage})
                    break
            else:
                total_cards += 1
                total_slot_per_device += slot_per_card
                # 统计出口2
                port_usage.append(
                    '板卡' + str(last_card) + ', 端口' + str(slot_per_card) + ', 已用' + str(slot_per_card_used))
                last_card = device_i[4]
                slot_per_card = 1
                slot_per_card_used = 0
                if device_i[7] != 'shutdown':
                    slot_per_card_used = 1
        else:
            # 统计出口3
            port_list.append(
                {'Device': last_device, 'Cards': total_cards, 'Slots': total_slot_per_device, 'Usage': port_usage})
            last_device = device_i[0]
            last_card = device_i[4]
            total_cards = 1
            slot_per_card = 1
            total_slot_per_device = 0
            slot_per_card_used = 0
            if device_i[7] != 'shutdown':
                slot_per_card_used = 1
            port_usage = []
            if index == len(device_frame.values):
                total_slot_per_device += slot_per_card
                # 统计出口2
                port_usage.append(
                    '板卡' + str(last_card) + ', 端口' + str(slot_per_card) + ', 已用' + str(slot_per_card_used))
                # 统计出口3
                port_list.append(
                    {'Device': last_device, 'Cards': total_cards, 'Slots': total_slot_per_device, 'Usage': port_usage})
    return pd.DataFrame(port_list)


######################IP处理部分######################
# 将ip列表中的数据编程IPSet格式
def mergeIP(iplist):
    ipset = IPSet()
    for iplist_i in iplist:
        ip = ''
        mask = ''
        try:
            for element in iplist_i.split(' '):
                if element == '':
                    continue
                if ip == '':
                    ip = element
                    continue
                if mask == '':
                    mask = element
            if ip != '' and mask != '':
                ipset.add(IP(ip).make_net(mask))
            elif ip != '':
                ipset.add(IP(ip))
        except AttributeError:
            continue
    return ipset


# 判断数字在范围内，例如 2 是否在 '1-3'中，sep为分隔符
def num_in_range(num, s_range, sep):
    s, e = [0, 0]
    for index, i in enumerate(s_range):
        if i.find(sep) >= 0:
            try:
                s = int(i[:i.find(sep)])
                e = int(i[i.find(sep) + 1:])
            except ValueError:
                logger.error('type err in func')
                return False, 0, 0
        else:
            try:
                s = int(i)
                e = s
            except:
                logger.error('invalid input range')
                return False, 0, 0
        if s > e:
            logger.error('invalid input range')
            return False
        if num >= s and num <= e:
            return True, i, index
    return False, 0, 0


# 字符串列表展开到数字列表，仅正数,不考虑重叠部分，['1-3','4-6','7']->[1,2,3,4,5,6,7]
def compressed_num_expand(s_range, sep):
    result = []
    s, e = [0, 0]
    for i in s_range:
        if i.find(sep) >= 0:
            try:
                s = int(i[:i.find(sep)])
                e = int(i[i.find(sep) + 1:])
            except ValueError:
                logger.error('ValueError in compressed_num_expand')
                return []
            for num_i in range(s, e + 1):
                result.append(num_i)
        else:
            result.append(int(i))
    result.sort()
    return result


# 正数数字列表的合并成字符串列表,[1,2,4,5,7] -> ['1-2','4-5','7']
def ordered_num_merge(num, sep):
    if num == None:
        return []
    num.sort()
    result = []
    try:
        s = num[0]
    except IndexError:
        return []
    e = s
    num.append(np.inf)
    for i in num:
        if i <= e and i >= s:
            continue
        if i < s:
            logger.debug('invalid input, num = ' + str(i) + ', s = ' + str(s))
            return
        if i == e + 1:
            e = i
        else:
            if e > s:
                result.append(str(s) + sep + str(e))
            else:
                result.append(str(s))
            s = i
            e = i
    return result


# 在一个带连字符sep的数字段中减去数字
def range_discard_num(num, range, sep):
    tf, subrange, index = num_in_range(num, range, sep)
    if tf:
        range.remove(subrange)
        if subrange.find(sep) >= 0:
            try:
                s = int(subrange[:subrange.find(sep)])
                e = int(subrange[subrange.find(sep) + 1:])
            except ValueError:
                logger.error('type err in func')
                return
            if num == s:
                if num + 1 == e:
                    range.insert(index, str(e))
                else:
                    range.insert(index, str(num + 1) + sep + str(e))
            elif num == e:
                if num - 1 == s:
                    range.insert(index, str(s))
                else:
                    range.insert(index, str(s) + sep + str(num - 1))
            else:
                if num + 1 == e:
                    range.insert(index, str(num + 1))
                else:
                    range.insert(index, str(num + 1) + sep + str(e))
                if num - 1 == s:
                    range.insert(index, str(num - 1))
                else:
                    range.insert(index, str(s) + sep + str(num - 1))
    else:
        return range
    return range


# 根据给定的地址范围，转译给定的地址段
def ip_long2cidr(str_in):
    ips = IPSet()
    for i in str_in:
        if i.find('-') >= 0:
            iplist = []
            ip_s = IP(i[:i.find('-')]).int()
            ip_e = IP(i[i.find('-') + 1:]).int()
            for ip_i in range(ip_s, ip_e + 1):
                iplist.append(IP(ip_i))
            ips.add(iplist)
        else:
            ips.add(IP(i))
    return ips


# 统计在给定的ip列表中，根据mask分段统计的地址数量，返回字符串
def ip_count(ipset_list, mask):
    result_dict = {}
    ip_prefix = []
    # 取字典类别数

    for ipset in ipset_list:
        tmp_prefix = ipset.net().make_net(mask)
        if tmp_prefix not in ip_prefix:
            ip_prefix.append(tmp_prefix)

    for prefix_i in ip_prefix:
        count = 0
        for ipset in ipset_list:
            tmp_prefix = ipset.net().make_net(mask)
            if prefix_i == tmp_prefix:
                count += ipset.len()
        result_dict.setdefault(prefix_i.strNormal(1), []).append(count)
    return str(result_dict)[1:-1]


def list_combined_sort(combined, sep):
    a1 = []
    a2 = []
    result = []
    for val in combined:
        if val.find(sep) >= 0:
            a1.append(val[:val.find(sep)])
            a2.append(val[val.find(sep) + 1:])
        else:
            logger.error('invalid input combined' + val)
            return []
    tmp = DataFrame({'a1': a1, 'a2': a2}).sort_values('a2')
    for index in range(len((tmp['a1']))):
        result.append(tmp['a1'].values[index] + sep + tmp['a2'].values[index])
    return result


def count_network_segment(network_list):
    dict_n = {}
    for seg in network_list:
        if seg.find('/') >= 0:
            dict_n.setdefault(seg[seg.find('/') + 1:], 0)
            dict_n[seg[seg.find('/') + 1:]] += 1
    return dict_n


# 导出Vlan统计信息


def export_ip_vlan(rootDir, partition, subffix, range_ip, range_vlan, count_mask):
    export_path = rootDir + os.path.sep + _export_dir
    if not os.path.isdir(export_path):
        os.mkdir(export_path)
    frame_all = files2df(rootDir, [partition, subffix])
    vlan_frame = frame_all[1]
    if isinstance(partition, list):
        tmp = ''
        for i in partition:
            if tmp == '':
                tmp = i
            else:
                tmp = tmp + ', ' + i
        partition = tmp

    logger.info(u'正在处理' + str(partition) + u'分区IP信息...')

    range_ip_all = copy.deepcopy(range_ip)
    range_ip_all_list = []
    range_ip_used_list = []
    range_ip_unused_list = []
    range_ip_used = mergeIP(vlan_frame['IP'].values)
    ip_usage = [ip_count(range_ip, count_mask), ip_count(range_ip_used, count_mask)]

    for ip_i in range_ip_all:
        range_ip_all_list.append(ip_i.strNormal(3))
    for ip_i in range_ip_used:
        range_ip_used_list.append(ip_i.strNormal(3))
    # 总IP-已用IP，做减法得到剩余IP
    range_ip_all.discard(range_ip_used)
    for ip_i in range_ip_all:
        range_ip_unused_list.append(ip_i.strNormal(1))
    # 对未用IP字符串根据掩码排序
    range_ip_unused_list = list_combined_sort(range_ip_unused_list, '/')

    ip_usage.append(ip_count(range_ip_all, count_mask))

    used_vlan_list_num = []  # 数值列表
    used_vlan_list = []
    #    unused_vlan_list = copy.deepcopy(range_vlan)
    unused_vlan_list = compressed_num_expand(range_vlan, '-')
    # vlan_frame['No'].values
    # 得到已用vlan号段的数字list
    for vlan_i in vlan_frame['No'].values:
        vlan_i = int(vlan_i)
        if vlan_i == 1:
            continue
        if vlan_i not in used_vlan_list:
            used_vlan_list_num.append(vlan_i)
    used_vlan_list_num.sort()
    # 从总集合减去逐个剔除used_vlan_list_num
    #    for num in used_vlan_list_num:
    #        unused_vlan_list = range_discard_num(num, unused_vlan_list, '-')
    for num in used_vlan_list_num:
        if num in unused_vlan_list:
            unused_vlan_list.remove(num)
    unused_vlan_list = ordered_num_merge(unused_vlan_list, '-')

    # 将数字list合并成带连字符"-"的形式
    used_vlan_list = ordered_num_merge(used_vlan_list_num, '-')

    # df要求长度统一，格式规整
    list_max_len = max([len(range_ip_all_list), len(range_ip_used_list), len(range_ip_unused_list), len(range_vlan),
                        len(used_vlan_list), len(unused_vlan_list)])
    for i in range(len(range_ip_all_list), list_max_len):
        range_ip_all_list.append('')
    for i in range(len(range_ip_used_list), list_max_len):
        range_ip_used_list.append('')
    for i in range(len(range_ip_unused_list), list_max_len):
        range_ip_unused_list.append('')
    for i in range(len(range_vlan), list_max_len):
        range_vlan.append('')
    for i in range(len(used_vlan_list), list_max_len):
        used_vlan_list.append('')
    for i in range(len(unused_vlan_list), list_max_len):
        unused_vlan_list.append('')

    # 保存到字典
    sumamary_ip_vlan = {u'1.1 IP分配范围': range_ip_all_list, u'1.2 IP已用': range_ip_used_list,
                        u'1.3 IP未用': range_ip_unused_list,
                        u'2.1 Vlan范围': range_vlan, u'2.2 Vlan已用': used_vlan_list, u'2.3 Vlan未用': unused_vlan_list}
    # 字典到df
    ip_df = DataFrame(sumamary_ip_vlan)
    # # 保存方式，需修改
    # ip_df.to_html(export_path + os.path.sep + 'VLAN+IP使用情况_' + str(partition) + '分区.html')
    # file_object = open(export_path + os.path.sep + 'VLAN+IP使用情况_' + str(partition) + '分区.html', 'a+')
    # try:
    #     unused_ip_seg = count_network_segment(range_ip_unused_list)
    #     unused_ip_seg = sorted(unused_ip_seg.items(), key=lambda unused_ip_seg: unused_ip_seg[0])
    #     file_object.write('\r\n<title>' + str(partition) + '</title>\r\n')
    #     file_object.write(
    #         '\r\n<td>' + str(partition) + '上共分配网段' + str(ip_usage[0]) + '个地址，已使用（额外包括连接管理和互联的IP）' + str(
    #             ip_usage[1]) + '个，剩余未分配的地址' + str(ip_usage[2]) + '个，未分配(网段，数量)为' + str(unused_ip_seg) + '</td>\r\n')
    # finally:
    #     file_object.close()

    unused_ip_seg = count_network_segment(range_ip_unused_list)
    unused_ip_seg = sorted(unused_ip_seg.items(), key=lambda unused_ip_seg: unused_ip_seg[0])
    diagnose = str(partition) + u'上共分配网段' + str(ip_usage[0]) + u'个地址，已使用（额外包括连接管理和互联的IP）' + str(
        ip_usage[1]) + u'个，剩余未分配的地址' + str(ip_usage[2]) + u'个，未分配(网段，数量)为' + str(unused_ip_seg)

    with pd.ExcelWriter(export_path + os.path.sep + str(partition) + '.xls') as writer:
        frame_all[0].to_excel(writer, sheet_name='Device')
        frame_all[1].to_excel(writer, sheet_name='Vlan')
        frame_all[2].to_excel(writer, sheet_name='Module')
    ip_df.to_excel(export_path + os.path.sep + u'VLAN+IP使用情况_' + str(partition) + u'分区.xls')
    file_rd = xlrd.open_workbook(export_path + os.path.sep + u'VLAN+IP使用情况_' + str(partition) + u'分区.xls',
                                 formatting_info=True, on_demand=True)
    file_st = file_rd.sheet_by_index(0)
    wt_workbook = xlwt.Workbook(encoding='uft-8')
    wt_worksheet = wt_workbook.add_sheet(str(partition)[:10])
    wt_worksheet.write(0, 0, diagnose)
    style0 = xlwt.XFStyle()
    style0.font = xlwt.Font()
    style0.font.name = 'Arial'
    style0.font.bold = True
    for row in range(file_st.nrows):
        for col in range(file_st.ncols - 1):
            if row == 0:
                wt_worksheet.write(row + 2, col, file_st.cell_value(row, col + 1), style0)
            else:
                wt_worksheet.write(row + 2, col, file_st.cell_value(row, col + 1))
    file_rd.release_resources()
    wt_workbook.save(export_path + os.path.sep + u'VLAN+IP使用情况_' + str(partition) + u'分区.xls')
    return sumamary_ip_vlan
