import paramiko
import threading
import pexpect
import pandas
from logger import logger
import time

def connect(hostname = str,username = str, password = str,cmd = []):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    paramiko.util.log_to_file('syslogin.log')
    try:
        ssh.connect(hostname,22,username,password,timeout=5)
        for m in cmd:
            stdin, stdout, stderr = ssh.exec_command(m)
            out = stdout.readlines()
            for o in out:
                print o,
        print '%s\tOK\n'%(hostname)
        logger.info(hostname)
    except :
        print '%s\tError\n'%(hostname)
        logger.error(hostname)
    finally:
        ssh.close()

def ping(IP = str):
    test = pexpect.spawn("ping -c1 %s" % (IP))
    result = "Access" if test.expect([pexpect.TIMEOUT,"1 packets transmitted, 1 received, 0% packet loss"],2) != 0 else "NA"
    logger.info (IP + " " + result)

if __name__=='__main__':
    cmd = ['display current']
    username = "zhouqiaozhen1"
    passwd = "!qaz2wsx"
    #threads = []
    print "Begin......"
    for i in range(1,255):
        ip = '192.168.31.'+str(i)
        #a=threading.Thread(target=connect,args=(ip,username,passwd,cmd))
        a = threading.Thread(target=ping,args = (ip,))
        a.start()
