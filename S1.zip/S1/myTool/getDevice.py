import hashlib
import ConfigParser
import xlrd
import pandas as pd
from pandas import Series, DataFrame
import numpy as np
import IPy
from IPy import IP, IPSet
import os


if __name__ == "__main__":
    m2 = hashlib.md5()
    m2.update("Abcdc")
    print m2.hexdigest()

    print os.listdir('..')

    config = ConfigParser.ConfigParser()
    with open("../res/config.cfg", "rw") as cfgfile:
        config.readfp(cfgfile)

    df1 = DataFrame()
    df1.from_csv('../res/desc1.csv')
    print df1
    a = "abc"
    print a.split("\r").__len__()