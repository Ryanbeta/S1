from netmiko.avaya.avaya_vsp_ssh import AvayaVspSSH
from netmiko.avaya.avaya_ers_ssh import AvayaErsSSH

__all__ = ['AvayaVspSSH', 'AvayaErsSSH']
