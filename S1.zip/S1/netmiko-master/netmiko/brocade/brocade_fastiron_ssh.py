from netmiko.ssh_connection import SSHConnection


class BrocadeFastironSSH(SSHConnection):
    '''Placeholder for Brocade FastIron'''
    def __init__(self, *args, **kwargs):
        raise NotImplementedError
