from netmiko.ssh_connection import SSHConnection


class BrocadeNetironSSH(SSHConnection):
    '''Placeholder for Brocade NetIron'''
    def __init__(self, *args, **kwargs):
        raise NotImplementedError
